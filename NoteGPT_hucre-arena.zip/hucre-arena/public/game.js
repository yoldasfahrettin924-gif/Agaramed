/* ===================================================================
   Hücre Arena — İstemci (canvas render + giriş yönetimi)
   Sunucu otoritedir; istemci sadece girdi yollar ve durumu çizer.
   =================================================================== */

(() => {
  'use strict';

  const socket = io();

  /* ----------------------------- DOM ----------------------------- */
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const mini = document.getElementById('minimap');
  const mctx = mini.getContext('2d');

  const menu = document.getElementById('menu');
  const hud = document.getElementById('hud');
  const deadScreen = document.getElementById('deadScreen');
  const joinForm = document.getElementById('joinForm');
  const nickInput = document.getElementById('nick');
  const nickErr = document.getElementById('nickErr');
  const playBtn = document.getElementById('playBtn');
  const onlineInfo = document.getElementById('onlineInfo');
  const lbList = document.getElementById('lbList');
  const massValue = document.getElementById('massValue');
  const fpsValue = document.getElementById('fpsValue');
  const bestMass = document.getElementById('bestMass');
  const hint = document.getElementById('hint');
  const soundBtn = document.getElementById('soundBtn');
  const mobileControls = document.getElementById('mobileControls');

  /* ----------------------------- Sabitler ----------------------------- */
  const rOf = (m) => Math.sqrt(m) * 4;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const BG = '#0b0818';

  const isTouch = window.matchMedia('(hover: none)').matches || 'ontouchstart' in window;

  /* ----------------------------- Durum ----------------------------- */
  let W = 4800, H = 4800;
  let myId = null;
  let joined = false;
  let alive = false;

  const food = new Map();     // id -> [x, y, color]
  const players = new Map();  // id -> {name, color, cells:[{x,y,m,tx,ty,tm}]}
  let viruses = [];           // [x, y, m]
  let pellets = [];           // [x, y, m, color]
  let lb = [];

  const cam = { x: W / 2, y: H / 2, zoom: 1 };
  const target = { x: W / 2, y: H / 2 };
  const pointer = { x: 0, y: 0, active: false };

  let dpr = 1;
  let vw = 0, vh = 0;

  let lastSend = 0;
  let lastLb = 0;
  let lastFps = 0;
  let frames = 0;
  let fps = 60;
  let ejectHeld = false;

  /* ----------------------------- Ses ----------------------------- */
  let audioCtx = null;
  let muted = false;
  function beep(freq, dur = 0.08, type = 'sine', gainVal = 0.05) {
    if (muted) return;
    try {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.type = type;
      o.frequency.value = freq;
      g.gain.value = gainVal;
      g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + dur);
      o.connect(g).connect(audioCtx.destination);
      o.start();
      o.stop(audioCtx.currentTime + dur);
    } catch (e) { /* sessiz geç */ }
  }

  /* ----------------------------- Boyutlandırma ----------------------------- */
  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    vw = window.innerWidth;
    vh = window.innerHeight;
    canvas.width = Math.floor(vw * dpr);
    canvas.height = Math.floor(vh * dpr);
    canvas.style.width = vw + 'px';
    canvas.style.height = vh + 'px';
  }
  window.addEventListener('resize', resize);
  resize();

  /* ----------------------------- Socket olayları ----------------------------- */
  socket.on('connect', () => {
    onlineInfo.textContent = '✓ Sunucuya bağlandı · ' + (isTouch ? 'Dokunmatik mod' : 'Fare + klavye');
  });
  socket.on('disconnect', () => {
    onlineInfo.textContent = '⚠ Bağlantı kesildi, yeniden deneniyor…';
  });

  socket.on('init', (data) => {
    myId = data.id;
    W = data.w;
    H = data.h;
    food.clear();
    for (const f of data.food) food.set(f[0], [f[1], f[2], f[3]]);
  });

  socket.on('food:add', (f) => food.set(f[0], [f[1], f[2], f[3]]));
  socket.on('food:remove', (id) => food.delete(id));

  socket.on('state', (s) => {
    const seen = new Set();

    for (const item of s.p) {
      const id = item[0], name = item[1], color = item[2], cells = item[3];
      seen.add(id);
      let pl = players.get(id);
      if (!pl) {
        pl = { name, color, cells: [] };
        players.set(id, pl);
      }
      pl.name = name;
      pl.color = color;

      const old = pl.cells;
      const used = new Array(old.length).fill(false);
      const next = [];

      for (const c of cells) {
        const x = c[0], y = c[1], m = c[2];
        // en yakın eski hücreyi eşle (animasyon sürekliliği için)
        let bestI = -1, bestD = Infinity;
        for (let i = 0; i < old.length; i++) {
          if (used[i]) continue;
          const dx = old[i].x - x, dy = old[i].y - y;
          const d = dx * dx + dy * dy;
          if (d < bestD) { bestD = d; bestI = i; }
        }
        if (bestI >= 0 && bestD < 500 * 500) {
          used[bestI] = true;
          const o = old[bestI];
          next.push({ x: o.x, y: o.y, m: o.m, tx: x, ty: y, tm: m });
        } else {
          next.push({ x, y, m, tx: x, ty: y, tm: m });
        }
      }
      pl.cells = next;
    }

    for (const id of Array.from(players.keys())) {
      if (!seen.has(id)) players.delete(id);
    }

    viruses = s.v || [];
    pellets = s.e || [];
    lb = s.lb || [];

    const t = performance.now();
    if (t - lastLb > 220) {
      lastLb = t;
      renderLeaderboard();
    }
  });

  socket.on('dead', (d) => {
    alive = false;
    bestMass.textContent = d.best;
    deadScreen.classList.remove('hidden');
    beep(120, 0.35, 'sawtooth', 0.07);
  });

  /* ----------------------------- Skor tablosu ----------------------------- */
  function renderLeaderboard() {
    let html = '';
    const myName = players.get(myId) ? players.get(myId).name : null;
    const top = lb.slice(0, 10);
    for (const row of top) {
      const isMe = !!myName && row[0] === myName && !row[3];
      html += `<li${isMe ? ' class="me"' : ''}>
        <i class="swatch" style="background:${row[2]}"></i>
        <span class="nm">${escapeHtml(row[0])}</span>
        ${row[3] ? '<span class="bot">BOT</span>' : ''}
        <span class="ms">${row[1]}</span>
      </li>`;
    }
    lbList.innerHTML = html || '<li><span class="nm">Henüz oyuncu yok</span></li>';
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  /* ----------------------------- Girdi ----------------------------- */
  canvas.addEventListener('mousemove', (e) => {
    pointer.x = e.clientX;
    pointer.y = e.clientY;
    pointer.active = true;
  });

  canvas.addEventListener('touchstart', onTouch, { passive: false });
  canvas.addEventListener('touchmove', onTouch, { passive: false });

  function onTouch(e) {
    if (!e.touches.length) return;
    e.preventDefault();
    pointer.x = e.touches[0].clientX;
    pointer.y = e.touches[0].clientY;
    pointer.active = true;
  }

  window.addEventListener('keydown', (e) => {
    if (!joined || !alive) return;
    if (e.code === 'Space') {
      e.preventDefault();
      socket.emit('split');
      beep(520, 0.1, 'triangle', 0.045);
    } else if (e.code === 'KeyW') {
      e.preventDefault();
      ejectHeld = true;
    }
  });

  window.addEventListener('keyup', (e) => {
    if (e.code === 'KeyW') ejectHeld = false;
  });

  document.getElementById('mSplit').addEventListener('click', () => {
    socket.emit('split');
    beep(520, 0.1, 'triangle', 0.045);
  });
  document.getElementById('mEject').addEventListener('click', () => {
    socket.emit('eject');
    beep(300, 0.06, 'square', 0.035);
  });

  hint.querySelector('#hintClose').addEventListener('click', () => hint.classList.add('hidden'));

  const icoOn = document.getElementById('icoOn');
  const icoOff = document.getElementById('icoOff');
  soundBtn.addEventListener('click', () => {
    muted = !muted;
    icoOn.classList.toggle('hidden', muted);
    icoOff.classList.toggle('hidden', !muted);
  });

  /* ----------------------------- Menü akışı ----------------------------- */
  const saved = localStorage.getItem('hucre:name');
  if (saved) nickInput.value = saved;

  joinForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = nickInput.value.trim();
    if (name.length < 2 || name.length > 14) {
      nickErr.classList.add('show');
      nickInput.focus();
      return;
    }
    nickErr.classList.remove('show');
    localStorage.setItem('hucre:name', name);

    playBtn.disabled = true;
    socket.emit('join', name);
    joined = true;
    alive = true;

    // kamera başlangıcı: kendi hücrenin etrafı
    setTimeout(() => {
      menu.classList.add('hidden');
      hud.classList.remove('hidden');
      playBtn.disabled = false;
      if (isTouch) mobileControls.style.display = 'flex';
      beep(660, 0.12, 'sine', 0.05);
    }, 120);
  });

  document.getElementById('respawnBtn').addEventListener('click', () => {
    deadScreen.classList.add('hidden');
    socket.emit('respawn');
    alive = true;
  });

  document.getElementById('menuBtn').addEventListener('click', () => {
    deadScreen.classList.add('hidden');
    menu.classList.remove('hidden');
    hud.classList.add('hidden');
    joined = false;
    alive = false;
    players.clear();
  });

  /* ----------------------------- Kamera ----------------------------- */
  function updateCamera(dt) {
    const me = players.get(myId);
    if (!me || !me.cells.length) return;

    let sx = 0, sy = 0, sm = 0;
    for (const c of me.cells) {
      sx += c.x * c.m;
      sy += c.y * c.m;
      sm += c.m;
    }
    const cx = sx / sm, cy = sy / sm;

    let span = 0;
    for (const c of me.cells) {
      span = Math.max(span, Math.hypot(c.x - cx, c.y - cy) + rOf(c.m));
    }
    span = Math.max(span, 18);

    let z = Math.min(vw, vh) / (span * 4.6);
    z = clamp(z, 0.1, 1.05);

    // kamerayı dünya sınırları içinde tut
    const hw = vw / 2 / z, hh = vh / 2 / z;
    const tx = W > hw * 2 ? clamp(cx, hw, W - hw) : W / 2;
    const ty = H > hh * 2 ? clamp(cy, hh, H - hh) : H / 2;

    const k = 1 - Math.exp(-dt * 9);
    cam.x += (tx - cam.x) * k;
    cam.y += (ty - cam.y) * k;
    cam.zoom += (z - cam.zoom) * (1 - Math.exp(-dt * 3.5));
  }

  /* ----------------------------- Çizim yardımcıları ----------------------------- */
  function shade(hex, amt) {
    const n = parseInt(hex.slice(1), 16);
    let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    r = clamp(Math.round(r + amt), 0, 255);
    g = clamp(Math.round(g + amt), 0, 255);
    b = clamp(Math.round(b + amt), 0, 255);
    return `rgb(${r},${g},${b})`;
  }

  function drawGrid(x0, y0, x1, y1) {
    const step = 100;
    ctx.lineWidth = 1 / cam.zoom;
    ctx.strokeStyle = 'rgba(255,255,255,0.045)';
    ctx.beginPath();
    const sx = Math.floor(x0 / step) * step;
    const sy = Math.floor(y0 / step) * step;
    for (let x = sx; x < x1; x += step) {
      ctx.moveTo(x, y0);
      ctx.lineTo(x, y1);
    }
    for (let y = sy; y < y1; y += step) {
      ctx.moveTo(x0, y);
      ctx.lineTo(x1, y);
    }
    ctx.stroke();

    // dünya sınırı
    ctx.strokeStyle = 'rgba(255,77,141,0.35)';
    ctx.lineWidth = 4 / cam.zoom;
    ctx.strokeRect(0, 0, W, H);
  }

  function drawFood(x0, y0, x1, y1) {
    ctx.globalAlpha = 0.95;
    for (const f of food.values()) {
      const x = f[0], y = f[1];
      if (x < x0 - 20 || x > x1 + 20 || y < y0 - 20 || y > y1 + 20) continue;
      ctx.beginPath();
      ctx.fillStyle = f[2];
      ctx.arc(x, y, 6, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function drawPellets() {
    for (const p of pellets) {
      const r = rOf(p[2]);
      ctx.beginPath();
      ctx.fillStyle = p[3];
      ctx.arc(p[0], p[1], r, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function drawViruses() {
    for (const v of viruses) {
      const r = rOf(v[2]);
      const spikes = 16;
      ctx.beginPath();
      for (let i = 0; i <= spikes * 2; i++) {
        const ang = (Math.PI * i) / spikes;
        const rad = i % 2 === 0 ? r * 1.12 : r * 0.9;
        const x = v[0] + Math.cos(ang) * rad;
        const y = v[1] + Math.sin(ang) * rad;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fillStyle = 'rgba(111,240,192,0.16)';
      ctx.strokeStyle = 'rgba(111,240,192,0.85)';
      ctx.lineWidth = 5;
      ctx.fill();
      ctx.stroke();
    }
  }

  function drawCells() {
    // küçükten büyüğe çiz
    const list = [];
    for (const [id, pl] of players) {
      for (const c of pl.cells) list.push({ id, pl, c });
    }
    list.sort((a, b) => a.c.m - b.c.m);

    for (const o of list) {
      const c = o.c;
      const r = rOf(c.m);
      const isMe = o.id === myId;

      // gövde
      ctx.beginPath();
      ctx.arc(c.x, c.y, r, 0, Math.PI * 2);
      ctx.fillStyle = o.pl.color;
      ctx.fill();

      // iç parlaklık
      const g = ctx.createRadialGradient(c.x - r * 0.3, c.y - r * 0.35, r * 0.1, c.x, c.y, r);
      g.addColorStop(0, 'rgba(255,255,255,0.30)');
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g;
      ctx.fill();

      // kenar
      ctx.lineWidth = Math.max(2, r * 0.06);
      ctx.strokeStyle = shade(o.pl.color, -55);
      ctx.stroke();

      if (isMe) {
        ctx.lineWidth = Math.max(1.5, r * 0.03);
        ctx.strokeStyle = 'rgba(255,255,255,0.55)';
        ctx.stroke();
      }

      // isim
      const px = r * cam.zoom;
      if (px > 11) {
        const fs = Math.max(11 / cam.zoom, r * 0.36);
        ctx.font = `800 ${fs}px "Plus Jakarta Sans", sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.lineWidth = fs * 0.22;
        ctx.strokeStyle = 'rgba(0,0,0,0.55)';
        ctx.strokeText(o.pl.name, c.x, c.y - fs * 0.12);
        ctx.fillStyle = '#fff';
        ctx.fillText(o.pl.name, c.x, c.y - fs * 0.12);

        if (px > 42) {
          const fs2 = fs * 0.66;
          ctx.font = `700 ${fs2}px "Plus Jakarta Sans", sans-serif`;
          ctx.lineWidth = fs2 * 0.24;
          ctx.strokeText(Math.round(c.m), c.x, c.y + fs * 0.75);
          ctx.fillStyle = 'rgba(255,255,255,0.82)';
          ctx.fillText(Math.round(c.m), c.x, c.y + fs * 0.75);
        }
      }
    }
  }

  /* ----------------------------- Minimap ----------------------------- */
  function drawMinimap() {
    const size = mini.width;
    const s = size / Math.max(W, H);

    mctx.clearRect(0, 0, size, size);
    mctx.fillStyle = 'rgba(11,8,24,0.9)';
    mctx.fillRect(0, 0, size, size);

    // ızgara
    mctx.strokeStyle = 'rgba(255,255,255,0.06)';
    mctx.lineWidth = 1;
    for (let i = 1; i < 4; i++) {
      const p = (size / 4) * i;
      mctx.beginPath();
      mctx.moveTo(p, 0); mctx.lineTo(p, size);
      mctx.moveTo(0, p); mctx.lineTo(size, p);
      mctx.stroke();
    }

    for (const [id, pl] of players) {
      for (const c of pl.cells) {
        const r = Math.max(2, rOf(c.m) * s * 0.75);
        mctx.beginPath();
        mctx.fillStyle = id === myId ? '#ffffff' : pl.color;
        mctx.arc(c.x * s, c.y * s, r, 0, Math.PI * 2);
        mctx.fill();
      }
    }

    // görüş alanı
    const hw = (vw / 2 / cam.zoom) * s;
    const hh = (vh / 2 / cam.zoom) * s;
    mctx.strokeStyle = 'rgba(255,255,255,0.55)';
    mctx.lineWidth = 1;
    mctx.strokeRect(cam.x * s - hw, cam.y * s - hh, hw * 2, hh * 2);
  }

  /* ----------------------------- Ana döngü ----------------------------- */
  let lastT = performance.now();

  function frame(t) {
    const dt = Math.min((t - lastT) / 1000, 0.05);
    lastT = t;

    // FPS
    frames++;
    if (t - lastFps > 500) {
      fps = Math.round((frames * 1000) / (t - lastFps));
      frames = 0;
      lastFps = t;
      if (fpsValue) fpsValue.textContent = fps;
    }

    // yumuşatma
    const k = 1 - Math.exp(-dt * 16);
    for (const pl of players.values()) {
      for (const c of pl.cells) {
        c.x += (c.tx - c.x) * k;
        c.y += (c.ty - c.y) * k;
        c.m += (c.tm - c.m) * k;
      }
    }

    if (joined && alive) {
      updateCamera(dt);

      // hedef noktayı dünyaya çevir
      if (pointer.active) {
        target.x = cam.x + (pointer.x - vw / 2) / cam.zoom;
        target.y = cam.y + (pointer.y - vh / 2) / cam.zoom;
      }

      // sunucuya girdi (25 Hz)
      if (t - lastSend > 40) {
        lastSend = t;
        socket.emit('input', { x: target.x, y: target.y });
      }

      // basılı tutarak kütle fırlatma
      if (ejectHeld && t - (frame._ejectT || 0) > 110) {
        frame._ejectT = t;
        socket.emit('eject');
        beep(300, 0.05, 'square', 0.03);
      }
    }

    render(dt);
    requestAnimationFrame(frame);
  }

  function render(dt) {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = BG;
    ctx.fillRect(0, 0, vw, vh);

    const halfW = vw / 2 / cam.zoom;
    const halfH = vh / 2 / cam.zoom;
    const x0 = cam.x - halfW, x1 = cam.x + halfW;
    const y0 = cam.y - halfH, y1 = cam.y + halfH;

    ctx.save();
    ctx.translate(vw / 2, vh / 2);
    ctx.scale(cam.zoom, cam.zoom);
    ctx.translate(-cam.x, -cam.y);

    drawGrid(x0, y0, x1, y1);
    drawFood(x0, y0, x1, y1);
    drawPellets();
    drawViruses();
    drawCells();

    ctx.restore();

    if (joined && alive) {
      drawMinimap();

      // kendi kütlem
      const me = players.get(myId);
      if (me) {
        let m = 0;
        for (const c of me.cells) m += c.m;
        massValue.textContent = Math.round(m);
      }
    }
  }

  requestAnimationFrame(frame);
})();
